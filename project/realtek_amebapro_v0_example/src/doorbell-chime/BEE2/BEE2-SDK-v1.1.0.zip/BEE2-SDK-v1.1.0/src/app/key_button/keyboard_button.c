/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     keyboardbutton.c
* @brief
* @details
* @author   Elliot Chen
* @date     2015-7-20
* @version  v1.0
*********************************************************************************************************
*/
#include <stddef.h>
#include <board.h>
#include <trace.h>
#include <gap_adv.h>
#include <gap_bond_le.h>
#include <gap_conn_le.h>
#include <os_timer.h>
#include <rtl876x_pinmux.h>
#include <rtl876x_rcc.h>
#include <rtl876x_gpio.h>
#include <rtl876x_nvic.h>

bool pair_press = false;
bool pair_release = false;

/**
* @brief   gpio button pinmux config
* @return  void
*/
void gpio_button_pinmux_config(void)
{
    Pinmux_Config(PAIR_BUTTON, DWGPIO);
}

/**
* @brief   gpio button pad config
* @return  void
*/
void gpio_button_pad_config(void)
{
    Pad_Config(PAIR_BUTTON, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    System_WakeUpPinEnable(PAIR_BUTTON, PAD_WAKEUP_POL_LOW, PAD_WK_DEBOUNCE_ENABLE);
}

/**
* @brief   gpio button pad enter dlps config
* @return  void
*/
void gpio_button_enter_dlps_config(void)
{
    Pad_Config(PAIR_BUTTON, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
}

/**
* @brief   gpio button pad exit dlps config
* @return  void
*/
void gpio_button_exit_dlps_config(void)
{
    Pad_Config(PAIR_BUTTON, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
}

/**
* @brief  keyboard button initialization function.
* @param   GPIO_INT_PARAM.
* @return  void
*/
void keyboard_button_init(void)
{
    /* Enable GPIO and hardware timer's clock */
    RCC_PeriphClockCmd(APBPeriph_GPIO,  APBPeriph_GPIO_CLOCK,  ENABLE);

    /* Initialize GPIO as interrupt mode */
    GPIO_InitTypeDef GPIO_Param;
    GPIO_StructInit(&GPIO_Param);
    GPIO_Param.GPIO_Pin = GPIO_GetPin(PAIR_BUTTON);
    GPIO_Param.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Param.GPIO_ITCmd = ENABLE;
    GPIO_Param.GPIO_ITTrigger = GPIO_INT_Trigger_EDGE;
    GPIO_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_Param.GPIO_ITDebounce = GPIO_INT_DEBOUNCE_ENABLE;
    GPIO_Param.GPIO_DebounceTime = 20;
    GPIO_Init(&GPIO_Param);

    /* Enable interrupt */
    GPIO_INTConfig(GPIO_GetPin(PAIR_BUTTON), ENABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(PAIR_BUTTON), DISABLE);

    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = GPIO20_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
}

/**
* @brief   Pair button interrupt handler
* @return  void
*/
void GPIO20_Handler(void)
{
    /*  Mask GPIO interrupt */
    GPIO_INTConfig(GPIO_GetPin(PAIR_BUTTON), DISABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(PAIR_BUTTON), ENABLE);
    GPIO_ClearINTPendingBit(GPIO_GetPin(PAIR_BUTTON));

    //T_IO_MSG button_msg;
    //button_msg.type = IO_MSG_TYPE_GPIO;

    if (GPIO_ReadInputDataBit(GPIO_GetPin(PAIR_BUTTON))) //Release
    {
        pair_press = false;
        //button_msg.subtype = KEYBOARD_PAIR_RELEASE;
        GPIO->INTPOLARITY &= ~GPIO_GetPin(PAIR_BUTTON); //Polarity Low
        System_WakeUpPinEnable(PAIR_BUTTON, PAD_WAKEUP_POL_LOW, PAD_WK_DEBOUNCE_ENABLE);
        APP_PRINT_INFO0("Pair button release !!!");
    }
    else
    {
        pair_press = true;
        //button_msg.subtype = KEYBOARD_PAIR_PRESS;
        GPIO->INTPOLARITY |= GPIO_GetPin(PAIR_BUTTON);   //Polarity High
        System_WakeUpPinEnable(PAIR_BUTTON, PAD_WAKEUP_POL_HIGH, PAD_WK_DEBOUNCE_ENABLE);
        APP_PRINT_INFO0("Pair button press !!!");
    }


    //app_send_msg_to_apptask(&button_msg);

    GPIO_MaskINTConfig(GPIO_GetPin(PAIR_BUTTON), DISABLE);
    GPIO_INTConfig(GPIO_GetPin(PAIR_BUTTON), ENABLE);

}

/**
* @brief   Pair button wakeup handler
* @return  void
*/
void handle_pair_button_wakeup(void)
{
    if (GPIO_ReadInputDataBit(GPIO_GetPin(PAIR_BUTTON)) && pair_press)
    {
        GPIO20_Handler();
    }
    else if (GPIO_ReadInputDataBit(GPIO_GetPin(PAIR_BUTTON)) == false && pair_press == false)
    {
        GPIO20_Handler();
    }
}