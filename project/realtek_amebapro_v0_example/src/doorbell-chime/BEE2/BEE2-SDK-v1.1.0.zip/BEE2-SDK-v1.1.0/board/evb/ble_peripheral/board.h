/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file     board.h
* @brief        Pin definitions
* @details
* @author   Chuanguo Xue
* @date     2015-4-7
* @version  v0.1
* *********************************************************************************************************
*/

#ifndef _BOARD_H_
#define _BOARD_H_

#ifdef __cplusplus
extern "C" {
#endif

/* if use user define dlps enter/dlps exit callback function */
#define USE_USER_DEFINE_DLPS_EXIT_CB      1
#define USE_USER_DEFINE_DLPS_ENTER_CB     1

/* if use any peripherals below, #define it 1 */
#define USE_I2C0_DLPS        0
#define USE_I2C1_DLPS        0
#define USE_TIM_DLPS         0
#define USE_QDECODER_DLPS    0
#define USE_IR_DLPS          0
#define USE_RTC_DLPS         0
#define USE_UART_DLPS        0
#define USE_ADC_DLPS         0
#define USE_SPI0_DLPS        0
#define USE_SPI1_DLPS        0
#define USE_SPI2W_DLPS       0
#define USE_KEYSCAN_DLPS     0
#define USE_DMIC_DLPS        0
#define USE_GPIO_DLPS        1
#define USE_PWM0_DLPS        0
#define USE_PWM1_DLPS        0
#define USE_PWM2_DLPS        0
#define USE_PWM3_DLPS        0


/* do not modify USE_IO_DRIVER_DLPS macro */
#define USE_IO_DRIVER_DLPS   (USE_I2C0_DLPS | USE_I2C1_DLPS | USE_TIM_DLPS | USE_QDECODER_DLPS\
                              | USE_IR_DLPS | USE_RTC_DLPS | USE_UART_DLPS | USE_SPI0_DLPS\
                              | USE_SPI1_DLPS | USE_SPI2W_DLPS | USE_KEYSCAN_DLPS | USE_DMIC_DLPS\
                              | USE_GPIO_DLPS | USE_USER_DEFINE_DLPS_EXIT_CB\
                              | USE_RTC_DLPS | USE_PWM0_DLPS | USE_PWM1_DLPS | USE_PWM2_DLPS\
                              | USE_PWM3_DLPS | USE_USER_DEFINE_DLPS_ENTER_CB)
															
/* Defines ------------------------------------------------------------------*/
/* P0_0, P0_1 is PWR_EN on EVB board */
#define GPIO_OUTPUT_PWR_0       P0_0
#define GPIO_PWR0_OUTPUT        GPIO_GetPin(GPIO_OUTPUT_PWR_0)
#define GPIO_OUTPUT_PWR_1       P0_1
#define GPIO_PWR1_OUTPUT        GPIO_GetPin(GPIO_OUTPUT_PWR_1)

#define GPIO_INPUT_PWR8715      P0_2
#define GPIO_PWR8715_INPUT      GPIO_GetPin(GPIO_INPUT_PWR8715)

#define GPIO_OUTPUT_TEST_MD_SEL H_0
#define GPIO_TEST_MD_SEL_OUTPUT GPIO_GetPin(GPIO_OUTPUT_TEST_MD_SEL)

/* P0_4, watchdog on EVB board */
#define GPIO_INPUT_WDT          P0_4
#define GPIO_WDT_INPUT          GPIO_GetPin(GPIO_INPUT_WDT)
#define GPIO_WDT_INPUT_IRQN     GPIO4_IRQn
#define GPIO_Wdt_Handler        GPIO4_Handler
/* P4_0, P4_1, P4_2, P4_3 is Event on EVB board */
#define GPIO_OUTPUT_EVENT_INT   P4_0
#define GPIO_EVENT_INT_OUTPUT   GPIO_GetPin(GPIO_OUTPUT_EVENT_INT)
#define GPIO_OUTPUT_EVENT_0     P4_1
#define GPIO_EVENT0_OUTPUT      GPIO_GetPin(GPIO_OUTPUT_EVENT_0)
#define GPIO_OUTPUT_EVENT_1     P4_2
#define GPIO_EVENT1_OUTPUT      GPIO_GetPin(GPIO_OUTPUT_EVENT_1)
#define GPIO_OUTPUT_EVENT_2     P4_3
#define GPIO_EVENT2_OUTPUT      GPIO_GetPin(GPIO_OUTPUT_EVENT_2)
/* uart on EVB board */
#define UART_TX_PIN                P3_3
#define UART_RX_PIN                P3_2

/*key*/
#define PAIR_BUTTON                P2_4

/*PIR P0_6*/
#define GPIO_INTPUT_EVENT_0   			P0_6
#define GPIO_EVENT0_INTPUT   				GPIO_GetPin(GPIO_INTPUT_EVENT_0)		
#define GPIO_EVENT0_INTPUT_IRQN     GPIO6_IRQn
#define GPIO_event0_Handler       	GPIO6_Handler

/*Button P2_7*/
#define GPIO_INTPUT_EVENT_1   			P2_7
#define GPIO_EVENT1_INTPUT   				GPIO_GetPin(GPIO_INTPUT_EVENT_1)		
#define GPIO_EVENT1_INTPUT_IRQN     GPIO23_IRQn
#define GPIO_event1_Handler       	GPIO23_Handler

/** ADC pin define.
  */
#define ADC_SAMPLE_PIN_0          P2_2
#define ADC_SAMPLE_PIN_1          P2_3

/*PIR*/
#define PIR_RX_PIN                P0_6

/*CHG LED*/
#define GPIO_INTPUT_CHG_OK_LED    P2_5
#define GPIO_CHG_OK_LED_INTPUT   		GPIO_GetPin(GPIO_INTPUT_CHG_OK_LED)		


/* LED1*/
#define GPIO_OUTPUT_LED_1       P0_5
#define GPIO_LED1_OUTPUT        GPIO_GetPin(GPIO_OUTPUT_LED_1)

/* USB_DET */
#define GPIO_INTPUT_USB_DET      	P2_6
#define GPIO_USB_DET_INTPUT   		GPIO_GetPin(GPIO_INTPUT_USB_DET)		


/* boot strap*/
#define BOOT_STRAP                P0_3

/* powerEN AmebaPro for load code*/
#define PRO_LOAD_CODE             P0_2

/* TEST_MD_SEL */
#define TEST_MD_SEL               P5_0
															
#ifdef __cplusplus
}
#endif

#endif

