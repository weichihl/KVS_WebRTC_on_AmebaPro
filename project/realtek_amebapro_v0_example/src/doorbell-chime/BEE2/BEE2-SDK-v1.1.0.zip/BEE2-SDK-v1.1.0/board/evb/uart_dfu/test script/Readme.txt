修改端口 波特率和升级的image路径
        self.boudrate = 9600
        self.com = 'com4'
        self.path = r'C:\Users\lance_lan\Desktop\app.bin'